-- Initialize the addon
local addonName, addonTable = ...
_G["AllforOneAddon"] = addonTable -- Make addonTable globally accessible
addonTable.inCombat = false
addonTable.rotationEnabled = true -- Add a flag to enable/disable rotation

-- Constants
local MINIMAP_BUTTON_SIZE = 32
local ICON_SIZE = 20
local OVERLAY_SIZE = 54
local MINIMAP_ANGLE = 45
local MINIMAP_RADIUS = 80

-- Cache global functions
local date = date
local print = print
local CreateFrame = CreateFrame
local UnitClass = UnitClass
local GetSpecialization = GetSpecialization
local GetSpecializationInfo = GetSpecializationInfo
local CombatLogGetCurrentEventInfo = CombatLogGetCurrentEventInfo
local UnitName = UnitName
local IsUsableSpell = IsUsableSpell
local GetSpellCooldown = GetSpellCooldown
local C_Timer = C_Timer

-- Log function with error handling
local function SafeLog(message)
    local timestamp = date("%Y-%m-%d %H:%M:%S") .. " - " .. message
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(timestamp)
    else
        print(timestamp)
    end
end
addonTable.Log = SafeLog

-- Create the minimap button
local function CreateMinimapButton()
    local button = CreateFrame("Button", "AllforOneMinimapButton", Minimap)
    button:SetSize(MINIMAP_BUTTON_SIZE, MINIMAP_BUTTON_SIZE)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(8)
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

    local icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture("Interface\\ICONS\\INV_Misc_QuestionMark")
    icon:SetSize(ICON_SIZE, ICON_SIZE)
    icon:SetPoint("CENTER")

    local overlay = button:CreateTexture(nil, "OVERLAY")
    overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    overlay:SetSize(OVERLAY_SIZE, OVERLAY_SIZE)
    overlay:SetPoint("TOPLEFT")

    button:SetScript("OnClick", function()
        addonTable.rotationEnabled = not addonTable.rotationEnabled
        local status = addonTable.rotationEnabled and "enabled" or "disabled"
        print("Rotation " .. status)
        SafeLog("Rotation " .. status)
    end)

    return button
end

local minimapButton = CreateMinimapButton()

-- Position the minimap button
local function UpdateMinimapButtonPosition()
    local angle = math.rad(MINIMAP_ANGLE)
    local x, y = cos(angle) * MINIMAP_RADIUS, sin(angle) * MINIMAP_RADIUS
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", x, y)
    minimapButton:Show() -- Ensure the button is shown
end

minimapButton:RegisterEvent("PLAYER_LOGIN")
minimapButton:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        UpdateMinimapButtonPosition()
    end
end)

-- Define the HandleChatCommand function
function addonTable.HandleChatCommand(msg)
    if msg == "toggle" then
        addonTable.rotationEnabled = not addonTable.rotationEnabled
        local status = addonTable.rotationEnabled and "enabled" or "disabled"
        print("Rotation " .. status)
        SafeLog("Rotation " .. status)
    else
        SafeLog("Chat command received: " .. msg)
        print("Chat command received: " .. msg)
    end
end

-- Initialize the current rotation function
local function InitializeRotationFunction()
    local class = select(2, UnitClass("player"))
    if GetSpecialization then
        local spec = GetSpecialization()
        if spec then
            local specInfo = GetSpecializationInfo(spec)
            if specInfo then
                addonTable.currentRotationFunction = addonTable.GetRotationFunction[class] and addonTable.GetRotationFunction[class][specInfo]
            else
                SafeLog("Failed to get specialization info.")
            end
        else
            SafeLog("Specialization not available yet.")
        end
    else
        SafeLog("GetSpecialization function is not available.")
    end
end

-- Create frame and register events
addonTable.frame = CreateFrame("Frame")
local events = {
    "PLAYER_LOGIN",
    "COMBAT_LOG_EVENT_UNFILTERED",
    "PLAYER_ENTERING_WORLD",
    "SPELLS_CHANGED",
    "ACTIVE_TALENT_GROUP_CHANGED",
    "PLAYER_LEVEL_UP",
    "PLAYER_REGEN_DISABLED", -- Entering combat
    "PLAYER_REGEN_ENABLED" -- Exiting combat
}
for _, event in ipairs(events) do
    addonTable.frame:RegisterEvent(event)
end

-- Register chat command
SLASH_ALLFORONE1 = "/allforone"
SlashCmdList["ALLFORONE"] = function(msg)
    addonTable.HandleChatCommand(msg) -- Call with addonTable prefix
end

-- Event handler function
addonTable.frame:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        print("AllforOne Addon Loaded")
        SafeLog("Addon Loaded")
    elseif event == "PLAYER_ENTERING_WORLD" then
        if not AllforOneConfig then
            AllforOneConfig = { settings = { scaling = true, uiSize = 1.0, color = "white" } }
        end
        addonTable.config = AllforOneConfig
        SafeLog("Player entered world.")
        -- Ensure textBox and settingsButton are defined before showing them
        if addonTable.textBox then addonTable.textBox:Show() end
        if addonTable.settingsButton then addonTable.settingsButton:Show() end
        C_Timer.After(1, function()
            if GetSpecialization then
                InitializeRotationFunction()
            else
                SafeLog("GetSpecialization not available, retrying...")
                C_Timer.After(1, InitializeRotationFunction)
            end
        end)
    elseif event == "PLAYER_LEVEL_UP" then
        local level = ...
        addonTable.ScaleUIBasedOnLevel(level)
        SafeLog("Player leveled up to " .. level)
    elseif event == "PLAYER_REGEN_DISABLED" then
        addonTable.inCombat = true
        SafeLog("Player entered combat.")
    elseif event == "PLAYER_REGEN_ENABLED" then
        addonTable.inCombat = false
        SafeLog("Player exited combat.")
    elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then
        local timestamp, subevent, _, sourceGUID, sourceName, _, _, destGUID, destName, _, _, spellId, spellName = CombatLogGetCurrentEventInfo()
        if subevent == "SPELL_CAST_SUCCESS" and sourceName == UnitName("player") then
            print("You cast " .. spellName)
            SafeLog("Spell cast: " .. spellName)
        end
    elseif event == "ACTIVE_TALENT_GROUP_CHANGED" then
        print("Specialization changed")
        SafeLog("Specialization changed")
        -- Reinitialize rotation function based on new spec
        C_Timer.After(1, function()
            if GetSpecialization then
                InitializeRotationFunction()
            else
                SafeLog("GetSpecialization not available, retrying...")
                C_Timer.After(1, InitializeRotationFunction)
            end
        end)
    else
        SafeLog("Unhandled event: " .. event)
    end
end)

-- Load rotation functions from separate files
local function LoadRotationFunctions()
    local classes = {"DEATHKNIGHT", "DEMONHUNTER", "DRUID", "HUNTER", "MAGE", "MONK", "PALADIN", "PRIEST", "ROGUE", "SHAMAN", "WARLOCK", "WARRIOR"}
    for _, class in ipairs(classes) do
        local rotationFile = "Interface\\AddOns\\" .. addonName .. "\\" .. class
        local loaded, reason = LoadAddOn(rotationFile)
        if not loaded then
            SafeLog("Failed to load rotation file for " .. class .. ": " .. reason)
        end
    end
end

LoadRotationFunctions()

-- Function to suggest spells
local function SuggestSpells()
    if addonTable.rotationEnabled and addonTable.inCombat then
        -- Example spell suggestion logic
        if IsUsableSpell("SpellName") and GetSpellCooldown("SpellName") == 0 then
            print("Suggest casting: SpellName")
        end
    end
end

local function Rotation()
    if not addonTable.rotationEnabled then
        return -- Exit the function if rotation is disabled
    end

    if addonTable.currentRotationFunction then
        addonTable.currentRotationFunction()
    end

    SuggestSpells() -- Call the suggestion function
end

-- Call the rotation function on a timer
C_Timer.NewTicker(1, Rotation)

-- Load the UI elements from a separate file
local function LoadUIElements()
    local uiFile = "Interface\\AddOns\\" .. addonName .. "\\UI.lua"
    local loaded, reason = LoadAddOn(uiFile)
    if not loaded then
        SafeLog("Failed to load UI file: " .. reason)
    end
end

LoadUIElements()

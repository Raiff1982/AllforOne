local function MeasureExecutionTime(func)
    local startTime = debugprofilestop()
    func()
    local endTime = debugprofilestop()
    print("Execution time: " .. (endTime - startTime) .. " ms")
end

local function InitializeUI()
    MeasureExecutionTime(function()
        local addonTable = _G["AllforOneAddonTable"]
        print("UI.lua: addonTable:", addonTable)

        if not addonTable then
            print("UI.lua: addonTable is nil, initializing fallback")
            _G["AllforOneAddonTable"] = { spellSequences = {} }
            addonTable = _G["AllforOneAddonTable"]
        end

        local classButtonNames = {
            ["WARRIOR"] = "Cast Warrior Spell",
            ["PALADIN"] = "Cast Paladin Spell",
            ["HUNTER"] = "Cast Hunter Spell",
            ["ROGUE"] = "Cast Rogue Spell",
            ["PRIEST"] = "Cast Priest Spell",
            ["DEATHKNIGHT"] = "Cast Death Knight Spell",
            ["SHAMAN"] = "Cast Shaman Spell",
            ["MAGE"] = "Cast Mage Spell",
            ["WARLOCK"] = "Cast Warlock Spell",
            ["MONK"] = "Cast Monk Spell",
            ["DRUID"] = "Cast Druid Spell",
            ["DEMONHUNTER"] = "Cast Demon Hunter Spell",
        }

        local defaultSpellSequences = {
            ["WARRIOR"] = {"Charge", "Mortal Strike", "Execute"},
            ["PALADIN"] = {"Judgment", "Crusader Strike", "Templar's Verdict"},
            ["HUNTER"] = {"Arcane Shot", "Multi-Shot", "Kill Command"},
            ["ROGUE"] = {"Sinister Strike", "Eviscerate", "Slice and Dice"},
            ["PRIEST"] = {"Smite", "Shadow Word: Pain", "Penance"},
            ["DEATHKNIGHT"] = {"Death Grip", "Heart Strike", "Death Strike"},
            ["SHAMAN"] = {"Lightning Bolt", "Flame Shock", "Lava Burst"},
            ["MAGE"] = {"Frostbolt", "Fireball", "Arcane Missiles"},
            ["WARLOCK"] = {"Shadow Bolt", "Corruption", "Chaos Bolt"},
            ["MONK"] = {"Tiger Palm", "Blackout Kick", "Rising Sun Kick"},
            ["DRUID"] = {"Wrath", "Moonfire", "Starfire"},
            ["DEMONHUNTER"] = {"Demon's Bite", "Chaos Strike", "Eye Beam"},
        }

        local settingsPanel = CreateFrame("Frame", "AllforOneSettingsPanel", UIParent, "BasicFrameTemplateWithInset")
        settingsPanel:SetSize(300, 400)
        settingsPanel:SetPoint("CENTER")
        settingsPanel:Hide()

        settingsPanel.title = settingsPanel:CreateFontString(nil, "OVERLAY")
        settingsPanel.title:SetFontObject("GameFontHighlight")
        settingsPanel.title:SetPoint("LEFT", settingsPanel.TitleBg, "LEFT", 5, 0)
        settingsPanel.title:SetText("AllforOne Settings")

        local spellInputs = {}
        for i = 1, 3 do
            local input = CreateFrame("EditBox", nil, settingsPanel, "InputBoxTemplate")
            input:SetSize(200, 30)
            input:SetPoint("TOP", settingsPanel, "TOP", 0, -50 - (i - 1) * 40)
            input:SetAutoFocus(false)
            input:SetScript("OnEscapePressed", input.ClearFocus)
            input:SetScript("OnEnterPressed", input.ClearFocus)
            spellInputs[i] = input
        end

        local errorMessage = settingsPanel:CreateFontString(nil, "OVERLAY")
        errorMessage:SetFontObject("GameFontRed")
        errorMessage:SetPoint("BOTTOM", settingsPanel, "BOTTOM", 0, 60)
        errorMessage:Hide()

        local function SaveSpellSequence()
            local class = select(2, UnitClass("player"))
            addonTable.spellSequences[class] = {}
            local valid = true
            for i, input in ipairs(spellInputs) do
                local spell = input:GetText()
                if spell and spell ~= "" then
                    local spellName = GetSpellInfo(spell)
                    if spellName then
                        table.insert(addonTable.spellSequences[class], spell)
                    else
                        valid = false
                        errorMessage:SetText("Invalid spell name: " .. spell)
                        errorMessage:Show()
                        break
                    end
                end
            end
            if valid then
                print("Spell sequence saved!")
                errorMessage:Hide()
                settingsPanel:Hide()
            end
        end

        local saveButton = CreateFrame("Button", nil, settingsPanel, "GameMenuButtonTemplate")
        saveButton:SetSize(100, 30)
        saveButton:SetPoint("BOTTOM", settingsPanel, "BOTTOM", -50, 20)
        saveButton:SetText("Save")
        saveButton:SetScript("OnClick", SaveSpellSequence)

        local function ResetSpellSequence()
            local class = select(2, UnitClass("player"))
            addonTable.spellSequences[class] = defaultSpellSequences[class]
            for i, input in ipairs(spellInputs) do
                input:SetText("")
            end
            print("Spell sequence reset to default!")
            errorMessage:Hide()
            settingsPanel:Hide()
        end

        local resetButton = CreateFrame("Button", nil, settingsPanel, "GameMenuButtonTemplate")
        resetButton:SetSize(100, 30)
        resetButton:SetPoint("BOTTOM", settingsPanel, "BOTTOM", 50, 20)
        resetButton:SetText("Reset")
        resetButton:SetScript("OnClick", ResetSpellSequence)

        local openSettingsButton = CreateFrame("Button", nil, UIParent, "UIPanelButtonTemplate")
        openSettingsButton:SetSize(140, 30)
        openSettingsButton:SetPoint("TOP", 0, -10)
        openSettingsButton:SetText("Customize Spells")
        openSettingsButton:SetScript("OnClick", function()
            settingsPanel:Show()
        end)

        local actionButton = CreateFrame("Button", nil, UIParent, "UIPanelButtonTemplate")
        actionButton:SetSize(140, 30)
        actionButton:SetPoint("TOP", openSettingsButton, "BOTTOM", 0, -10)
        actionButton:SetFrameLevel(UIParent:GetFrameLevel() + 1)

        actionButton:SetMovable(true)
        actionButton:EnableMouse(true)
        actionButton:RegisterForDrag("LeftButton")
        actionButton:SetScript("OnDragStart", actionButton.StartMoving)
        actionButton:SetScript("OnDragStop", actionButton.StopMovingOrSizing)

        actionButton:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText("Click to cast the next spell in the sequence.", nil, nil, nil, nil, true)
            GameTooltip:Show()
        end)

        actionButton:SetScript("OnLeave", function(self)
            GameTooltip:Hide()
        end)

        local function GetSpellSequence()
            local _, playerClass = UnitClass("player")
            return addonTable.spellSequences[playerClass] or {}
        end

        local function GetButtonName()
            local _, playerClass = UnitClass("player")
            return classButtonNames[playerClass] or "Cast Next Spell"
        end

        local emergencySpells = {
            {name = "EmergencyHeal", priority = 1, condition = function() return UnitHealth("player") / UnitHealthMax("player") < 0.2 end},
            {name = "DefensiveCooldown", priority = 2, condition = function() return UnitHealth("player") / UnitHealthMax("player") < 0.5 and not UnitBuff("player", "DefensiveBuff") end},
            {name = "CrowdControl", priority = 3, condition = function() return UnitAffectingCombat("player") and UnitHealth("target") / UnitHealthMax("target") > 0.8 end},
        }

        table.sort(emergencySpells, function(a, b) return a.priority < b.priority end)

        local function GetPrioritySpell()
            for _, spell in ipairs(emergencySpells) do
                if spell.condition() then
                    return spell.name
                end
            end

            local spells = {
                {name = "Spell1", priority = function() return IsUsableSpell("Spell1") and GetSpellCooldown("Spell1") == 0 end},
                {name = "Spell2", priority = function() return IsUsableSpell("Spell2") and GetSpellCooldown("Spell2") == 0 end},
            }

            for _, spell in ipairs(spells) do
                if spell.priority() then
                    return spell.name
                end
            end

            return nil
        end

        local function CastNextSpell()
            local class = select(2, UnitClass("player"))
            local spellSequence = addonTable.spellSequences[class] or {}
            if #spellSequence > 0 then
                local nextSpell = table.remove(spellSequence, 1)
                table.insert(spellSequence, nextSpell)
                CastSpellByName(nextSpell)
            end
        end

        local function OnActionButtonClick()
            local prioritySpell = GetPrioritySpell()
            if prioritySpell then
                CastSpellByName(prioritySpell)
            else
                CastNextSpell()
            end
        end

        actionButton:SetScript("OnClick", OnActionButtonClick)
        actionButton:SetText(GetButtonName())
    end)
end

InitializeUI()

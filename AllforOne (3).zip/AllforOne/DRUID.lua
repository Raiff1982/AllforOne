return function(addonTable)
    -- Ensure the GetRotationFunction table exists
    addonTable.GetRotationFunction = addonTable.GetRotationFunction or {}

    -- Helper function to cast a spell if usable and off cooldown
    local function castIfUsable(spellName, debuffCheck)
        local usable, noCooldown = IsUsableSpell(spellName), GetSpellCooldown(spellName) == 0
        if usable and noCooldown and (not debuffCheck or not UnitDebuff("target", spellName)) then
            CastSpellByName(spellName)
        end
    end

    -- Define rotation logic for Druid specializations
    addonTable.GetRotationFunction["DRUID"] = {
        ["BALANCE"] = function()
            -- Balance Druid rotation logic
            castIfUsable("Moonfire", true)
            castIfUsable("Sunfire", true)
            castIfUsable("Starsurge")
            castIfUsable("Starfire")
            castIfUsable("Wrath")
        end,
        ["FERAL"] = function()
            -- Feral Druid rotation logic
            castIfUsable("Rake", true)
            castIfUsable("Rip", true)
            castIfUsable("Shred")
            castIfUsable("Ferocious Bite")
        end,
        ["GUARDIAN"] = function()
            -- Guardian Druid rotation logic
            castIfUsable("Mangle")
            castIfUsable("Thrash")
            castIfUsable("Ironfur")
            castIfUsable("Frenzied Regeneration")
        end,
        ["RESTORATION"] = function()
            -- Restoration Druid rotation logic
            castIfUsable("Rejuvenation")
            castIfUsable("Regrowth")
            castIfUsable("Wild Growth")
            castIfUsable("Swiftmend")
        end,
    }
end

-- SHAMAN.lua
return function(addonTable)
    -- Ensure the GetRotationFunction table exists
    addonTable.GetRotationFunction = addonTable.GetRotationFunction or {}

    -- Helper function to cast a spell if usable and off cooldown
    local function castIfUsable(spellName)
        local usable, noCooldown = IsUsableSpell(spellName), GetSpellCooldown(spellName) == 0
        if usable and noCooldown then
            CastSpellByName(spellName)
        end
    end

    -- Define rotation logic for Shaman specializations
    addonTable.GetRotationFunction["SHAMAN"] = {
        ["ELEMENTAL"] = function()
            -- Elemental Shaman rotation logic
            castIfUsable("Flame Shock")
            castIfUsable("Lava Burst")
            castIfUsable("Earth Shock")
            castIfUsable("Lightning Bolt")
        end,
        ["ENHANCEMENT"] = function()
            -- Enhancement Shaman rotation logic
            castIfUsable("Stormstrike")
            castIfUsable("Lava Lash")
            castIfUsable("Flame Shock")
            castIfUsable("Feral Spirit")
        end,
        ["RESTORATION"] = function()
            -- Restoration Shaman rotation logic
            castIfUsable("Riptide")
            castIfUsable("Healing Wave")
            castIfUsable("Chain Heal")
            castIfUsable("Healing Rain")
        end,
    }
end

-- EVOKER.lua
return function(addonTable)
    -- Ensure the GetRotationFunction table exists
    addonTable.GetRotationFunction = addonTable.GetRotationFunction or {}

    -- Helper function to cast a spell if usable and off cooldown
    local function castIfUsable(spellName)
        local usable, noCooldown = IsUsableSpell(spellName), GetSpellCooldown(spellName) == 0
        if usable and noCooldown then
            CastSpellByName(spellName)
        end
    end

    -- Define rotation logic for Evoker specializations
    addonTable.GetRotationFunction["EVOKER"] = {
        ["DEVASTATION"] = function()
            -- Devastation Evoker rotation logic
            castIfUsable("Azure Strike")
            castIfUsable("Fire Breath")
            castIfUsable("Disintegrate")
            castIfUsable("Eternity Surge")
        end,
        ["PRESERVATION"] = function()
            -- Preservation Evoker rotation logic
            castIfUsable("Living Flame")
            castIfUsable("Emerald Blossom")
            castIfUsable("Reversion")
            castIfUsable("Dream Breath")
        end,
    }
end

local function MeasureExecutionTime(func)
    local startTime = debugprofilestop()
    func()
    local endTime = debugprofilestop()
    print("Execution time: " .. (endTime - startTime) .. " ms")
end

local function InitializeUI()
    MeasureExecutionTime(function()
        local addonTable = _G["AllforOneAddon"]
        local L = _G["AllforOneLocalization"]
        print("UI.lua: addonTable:", addonTable)

        if not addonTable then
            print("UI.lua: addonTable is nil, initializing fallback")
            _G["AllforOneAddon"] = { spellSequences = {} }
            addonTable = _G["AllforOneAddon"]
        end

        local classButtonNames = {
            ["WARRIOR"] = "Cast Warrior Spell",
            ["PALADIN"] = "Cast Paladin Spell",
            ["HUNTER"] = "Cast Hunter Spell",
            ["ROGUE"] = "Cast Rogue Spell",
            ["PRIEST"] = "Cast Priest Spell",
            ["DEATHKNIGHT"] = "Cast Death Knight Spell",
            ["SHAMAN"] = "Cast Shaman Spell",
            ["MAGE"] = "Cast Mage Spell",
            ["WARLOCK"] = "Cast Warlock Spell",
            ["MONK"] = "Cast Monk Spell",
            ["DRUID"] = "Cast Druid Spell",
            ["DEMONHUNTER"] = "Cast Demon Hunter Spell",
            ["EVOKER"] = "Cast Evoker Spell",  -- Added Evoker class
        }

        local defaultSpellSequences = {
            ["WARRIOR"] = {"Charge", "Mortal Strike", "Execute"},
            ["PALADIN"] = {"Judgment", "Crusader Strike", "Templar's Verdict"},
            ["HUNTER"] = {"Arcane Shot", "Multi-Shot", "Kill Command"},
            ["ROGUE"] = {"Sinister Strike", "Eviscerate", "Slice and Dice"},
            ["PRIEST"] = {"Smite", "Shadow Word: Pain", "Penance"},
            ["DEATHKNIGHT"] = {"Death Grip", "Heart Strike", "Death Strike"},
            ["SHAMAN"] = {"Lightning Bolt", "Flame Shock", "Lava Burst"},
            ["MAGE"] = {"Frostbolt", "Fireball", "Arcane Missiles"},
            ["WARLOCK"] = {"Shadow Bolt", "Corruption", "Chaos Bolt"},
            ["MONK"] = {"Tiger Palm", "Blackout Kick", "Rising Sun Kick"},
            ["DRUID"] = {"Wrath", "Moonfire", "Starfire"},
            ["DEMONHUNTER"] = {"Demon's Bite", "Chaos Strike", "Eye Beam"},
            ["EVOKER"] = {"Azure Strike", "Fire Breath", "Disintegrate"},  -- Added Evoker spells
        }

        -- Create the main frame for the options panel
        local optionsFrame = CreateFrame("Frame", "AllforOneOptionsFrame", InterfaceOptionsFramePanelContainer)
        optionsFrame.name = "AllforOne"
        InterfaceOptions_AddCategory(optionsFrame)

        -- Title for the options panel
        local title = optionsFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", 16, -16)
        title:SetText("AllforOne Addon Options")

        -- Checkbox to enable/disable rotation
        local rotationCheckbox = CreateFrame("CheckButton", nil, optionsFrame, "InterfaceOptionsCheckButtonTemplate")
        rotationCheckbox:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
        rotationCheckbox.Text:SetText(GetLocalizedText("Enable Rotation"))
        rotationCheckbox:SetChecked(addonTable.rotationEnabled)
        rotationCheckbox:SetScript("OnClick", function(self)
            addonTable.rotationEnabled = self:GetChecked()
            local status = addonTable.rotationEnabled and GetLocalizedText("Rotation enabled") or GetLocalizedText("Rotation disabled")
            print(status)
            SafeLog(status)
        end)
        rotationCheckbox.tooltipText = "Toggle the rotation feature on or off."

        -- Dropdown menu for selecting class spell sequences
        local classDropdown = CreateFrame("Frame", "AllforOneClassDropdown", optionsFrame, "UIDropDownMenuTemplate")
        classDropdown:SetPoint("TOPLEFT", rotationCheckbox, "BOTTOMLEFT", -16, -8)
        UIDropDownMenu_SetWidth(classDropdown, 180)
        UIDropDownMenu_SetText(classDropdown, GetLocalizedText("Select Class"))
        classDropdown.tooltipText = "Select your class to customize spell sequences."

        local classes = {
            "WARRIOR", "PALADIN", "HUNTER", "ROGUE", "PRIEST",
            "DEATHKNIGHT", "SHAMAN", "MAGE", "WARLOCK", "MONK",
            "DRUID", "DEMONHUNTER", "EVOKER"  -- Added Evoker class
        }

        UIDropDownMenu_Initialize(classDropdown, function(self, level, menuList)
            local info = UIDropDownMenu_CreateInfo()
            for _, class in ipairs(classes) do
                info.text = class
                info.func = function()
                    UIDropDownMenu_SetSelectedName(classDropdown, class)
                    -- Handle class selection logic here
                    print("Selected class: " .. class)
                    SafeLog("Selected class: " .. class)
                end
                UIDropDownMenu_AddButton(info)
            end
        end)

        -- Button to open the tutorial window
        local tutorialButton = CreateFrame("Button", nil, optionsFrame, "UIPanelButtonTemplate")
        tutorialButton:SetPoint("TOPLEFT", classDropdown, "BOTTOMLEFT", 16, -8)
        tutorialButton:SetSize(180, 22)
        tutorialButton:SetText(GetLocalizedText("Open Tutorial"))
        tutorialButton:SetScript("OnClick", function()
            addonTable:Tutorials(true)
        end)
        tutorialButton.tooltipText = "Open the tutorial window to learn more about AllforOne."

        -- Function to open the options panel
        local function OpenOptionsPanel()
            InterfaceOptionsFrame_OpenToCategory(optionsFrame)
            InterfaceOptionsFrame_OpenToCategory(optionsFrame) -- Call twice to ensure it opens correctly
        end

        -- Slash command to open the options panel
        SLASH_ALLFORONE1 = "/allforone"
        SlashCmdList["ALLFORONE"] = OpenOptionsPanel

        -- Additional UI initialization code here
    end)
end

-- Ensure the UI is initialized when the addon loads
InitializeUI()

local addonName, addonTable = ...

-- Ensure the GetRotationFunction table exists
addonTable.GetRotationFunction = addonTable.GetRotationFunction or {}

-- Define the tutorial messages
addonTable.TutorialList = {
    "?? Welcome to AllforOne! Ready to enhance your gameplay? Let's get started!",
    "?? To access the settings, type /allforone. Customize your experience to fit your playstyle!",
    "??? You can tweak the UI by heading to the settings menu. Make it yours!",
    "?? Need help or want to chat with other users? Visit our website or join our Discord community!",
    "?? Remember to backup your settings regularly. You don't want to lose your perfect setup!",
    "?? Use /allforone help to see all available commands. Knowledge is power!",
    "?? Toggle the rotation feature by clicking the minimap button. Keep your rotations sharp!",
    "?? Check out the minimap button for quick access to AllforOne features. It's your new best friend!",
    "?? Monitor your performance and adjust settings on the fly. Stay ahead of the game!",
    "?? Enjoy the enhanced gameplay experience with AllforOne. Happy adventuring!"
}

-- Load class-specific rotation files
local classes = {
    "DEATHKNIGHT",
    "DEMONHUNTER",
    "DRUID",
    "HUNTER",
    "MAGE",
    "MONK",
    "PALADIN",
    "PRIEST",
    "ROGUE",
    "SHAMAN",
    "WARLOCK",
    "WARRIOR",
    "EVOKER"  -- Added Evoker class
}

for _, class in ipairs(classes) do
    local classFile = "Interface\\AddOns\\" .. addonName .. "\\" .. class .. ".lua"
    local loadClassFile = assert(loadfile(classFile))
    loadClassFile(addonTable)
end

-- Initialize the addon
_G["AllforOneAddon"] = addonTable -- Make addonTable globally accessible
addonTable.inCombat = false
addonTable.rotationEnabled = true -- Add a flag to enable/disable rotation

-- Constants
local MINIMAP_BUTTON_SIZE = 32
local ICON_SIZE = 20
local OVERLAY_SIZE = 54
local MINIMAP_ANGLE = 45
local MINIMAP_RADIUS = 80

-- Cache global functions
local date = date
local print = print
local CreateFrame = CreateFrame
local UnitClass = UnitClass
local GetSpecialization = GetSpecialization
local GetSpecializationInfo = GetSpecializationInfo
local CombatLogGetCurrentEventInfo = CombatLogGetCurrentEventInfo
local UnitName = UnitName
local IsUsableSpell = IsUsableSpell
local GetSpellCooldown = GetSpellCooldown
local C_Timer = C_Timer

-- Log function with error handling
local function SafeLog(message)
    local timestamp = date("%Y-%m-%d %H:%M:%S") .. " - " .. message
    if DEFAULT_CHAT_FRAME then
        DEFAULT_CHAT_FRAME:AddMessage(timestamp)
    else
        print(timestamp)
    end
end
addonTable.Log = SafeLog

-- Create the minimap button
local function CreateMinimapButton()
    local button = CreateFrame("Button", "AllforOneMinimapButton", Minimap)
    button:SetSize(MINIMAP_BUTTON_SIZE, MINIMAP_BUTTON_SIZE)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(8)
    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    local icon = button:CreateTexture(nil, "BACKGROUND")
    icon:SetTexture("Interface\\ICONS\\INV_Misc_QuestionMark")
    icon:SetSize(ICON_SIZE, ICON_SIZE)
    icon:SetPoint("CENTER")
    local overlay = button:CreateTexture(nil, "OVERLAY")
    overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    overlay:SetSize(OVERLAY_SIZE, OVERLAY_SIZE)
    overlay:SetPoint("TOPLEFT")
    button:SetScript("OnClick", function()
        addonTable.rotationEnabled = not addonTable.rotationEnabled
        local status = addonTable.rotationEnabled and "enabled" or "disabled"
        print("Rotation " .. status)
        SafeLog("Rotation " .. status)
    end)
    return button
end

local minimapButton = CreateMinimapButton()

-- Position the minimap button
local function UpdateMinimapButtonPosition()
    local angle = math.rad(MINIMAP_ANGLE)
    local x, y = cos(angle) * MINIMAP_RADIUS, sin(angle) * MINIMAP_RADIUS
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", x, y)
    minimapButton:Show() -- Ensure the button is shown
end

minimapButton:RegisterEvent("PLAYER_LOGIN")
minimapButton:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        UpdateMinimapButtonPosition()
        InitializeUI() -- Initialize the UI when the addon is loaded
    end
end)

-- Initialize the current rotation function
local function InitializeRotationFunction()
    local class = select(2, UnitClass("player"))
    if GetSpecialization then
        local spec = GetSpecialization()
        if spec then
            local specInfo = GetSpecializationInfo(spec)
            if specInfo then
                addonTable.currentRotationFunction = addonTable.GetRotationFunction[class] and addonTable.GetRotationFunction[class][specInfo]
            else
                SafeLog("Failed to get specialization info.")
            end
        else
            SafeLog("Specialization not available yet.")
            C_Timer.After(1, InitializeRotationFunction)
        end
    else
        SafeLog("GetSpecialization function is not available.")
    end
end

-- Create frame and register events
addonTable.frame = CreateFrame("Frame")
local events = {
    "PLAYER_LOGIN",
    "COMBAT_LOG_EVENT_UNFILTERED",
    "PLAYER_ENTERING_WORLD",
    "SPELLS_CHANGED",
    "ACTIVE_TALENT_GROUP_CHANGED",
    "PLAYER_LEVEL_UP",
    "PLAYER_REGEN_DISABLED", -- Entering combat
    "PLAYER_REGEN_ENABLED" -- Exiting combat
}
for _, event in ipairs(events) do
    addonTable.frame:RegisterEvent(event)
end

-- Register chat command
SLASH_ALLFORONE1 = "/allforone"
SlashCmdList["ALLFORONE"] = function(msg)
    addonTable.HandleChatCommand(msg) -- Call with addonTable prefix
end

-- Event handler function
addonTable.frame:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        print("AllforOne Addon Loaded")
        SafeLog("Addon Loaded")
    elseif event == "PLAYER_ENTERING_WORLD" then
        if not AllforOneConfig then
            AllforOneConfig = { settings = { scaling = true, uiSize = 1.0, color = "white" } }
        end
        addonTable.config = AllforOneConfig
        SafeLog("Player entered world.")
        -- Ensure textBox and settingsButton are defined before showing them
        if addonTable.textBox then addonTable.textBox:Show() end
    elseif event == "SPELLS_CHANGED" then
        SafeLog("Spells changed, updating rotation function.")
        InitializeRotationFunction()
    elseif event == "PLAYER_LEVEL_UP" then
        SafeLog("Player leveled up, updating rotation function.")
        InitializeRotationFunction()
    elseif event == "PLAYER_REGEN_DISABLED" then
        addonTable.inCombat = true
        SafeLog("Entering combat.")
    elseif event == "PLAYER_REGEN_ENABLED" then
        addonTable.inCombat = false
        SafeLog("Exiting combat.")
    end
end)

-- Enhanced Error Handling
local function SafeExecute(func, ...)
    local success, result = pcall(func, ...)
    if not success then
        SafeLog("Error: " .. result)
    end
    return success, result
end

-- Example usage of SafeExecute
SafeExecute(function()
    -- Your code here
end)

-- Integration with ActionBarAPI
local function InitializeActionBarIntegration()
    -- Ensure ActionBarAPI is available
    if not ActionBarAPI then
        SafeLog("ActionBarAPI not found!")
        return
    end

    -- Example: Interact with ActionBarAPI to get action buttons
    local actionButtons = ActionBarAPI:GetActionButtons(true)
    for button, action in pairs(actionButtons) do
        SafeLog("Found action button: " .. button:GetName() .. " with action ID: " .. action)
        -- Example: Add custom logic to interact with action buttons
    end
end

-- Call InitializeActionBarIntegration when the addon is loaded
addonTable.frame:RegisterEvent("PLAYER_LOGIN")
addonTable.frame:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_LOGIN" then
        print("AllforOne Addon Loaded")
        SafeLog("Addon Loaded")
        InitializeActionBarIntegration() -- Initialize ActionBarAPI integration
    elseif event == "PLAYER_ENTERING_WORLD" then
        if not AllforOneConfig then
            AllforOneConfig = { settings = { scaling = true, uiSize = 1.0, color = "white" } }
        end
        addonTable.config = AllforOneConfig
        SafeLog("Player entered world.")
        -- Ensure textBox and settingsButton are defined before showing them
    if addonTable.textBox then addonTable.textBox:Show() end
    elseif event == "SPELLS_CHANGED" then
        SafeLog("Spells changed, updating rotation function.")
        InitializeRotationFunction()
    elseif event == "PLAYER_LEVEL_UP" then
        SafeLog("Player leveled up, updating rotation function.")
        InitializeRotationFunction()
    elseif event == "PLAYER_REGEN_DISABLED" then
        addonTable.inCombat = true
        SafeLog("Entering combat.")
    elseif event == "PLAYER_REGEN_ENABLED" then
        addonTable.inCombat = false
        SafeLog("Exiting combat.")
    end
end)

-- Tutorial System
addonTable.TutorialList = {
    "?? Welcome to AllforOne! Ready to enhance your gameplay? Let's get started!",
    "?? To access the settings, type /allforone. Customize your experience to fit your playstyle!",
    "??? You can tweak the UI by heading to the settings menu. Make it yours!",
    "?? Need help or want to chat with other users? Visit our website or join our Discord community!",
    "?? Remember to backup your settings regularly. You don't want to lose your perfect setup!",
    "?? Use /allforone help to see all available commands. Knowledge is power!",
    "?? Toggle the rotation feature by clicking the minimap button. Keep your rotations sharp!",
    "?? Check out the minimap button for quick access to AllforOne features. It's your new best friend!",
    "?? Monitor your performance and adjust settings on the fly. Stay ahead of the game!",
    "?? Enjoy the enhanced gameplay experience with AllforOne. Happy adventuring!"
}

function addonTable:SetNextTutorial()
    addonTable.db.currentTutorial = addonTable.db.currentTutorial or 0
    addonTable.db.currentTutorial = addonTable.db.currentTutorial + 1

    if addonTable.db.currentTutorial > #addonTable.TutorialList then
        addonTable.db.currentTutorial = 1
    end

    AllforOneTutorialWindow.desc:SetText(addonTable.TutorialList[addonTable.db.currentTutorial])
end

function addonTable:SetPrevTutorial()
    addonTable.db.currentTutorial = addonTable.db.currentTutorial or 0
    addonTable.db.currentTutorial = addonTable.db.currentTutorial - 1

    if addonTable.db.currentTutorial <= 0 then
        addonTable.db.currentTutorial = #addonTable.TutorialList
    end

    AllforOneTutorialWindow.desc:SetText(addonTable.TutorialList[addonTable.db.currentTutorial])
end

function addonTable:SpawnTutorialFrame()
    local f = CreateFrame('Frame', 'AllforOneTutorialWindow', UIParent)
    f:SetFrameStrata('DIALOG')
    f:SetToplevel(true)
    f:SetClampedToScreen(true)
    f:SetSize(360, 110)
    f:SetTemplate('Transparent')
    f:Hide()

    local header = CreateFrame('Button', nil, f)
    header:SetTemplate(nil, true)
    header:SetSize(120, 25)
    header:SetPoint('CENTER', f, 'TOP')
    header:SetFrameLevel(header:GetFrameLevel() + 2)

    local title = header:CreateFontString(nil, 'OVERLAY')
    title:FontTemplate()
    title:SetPoint('CENTER', header, 'CENTER')
    title:SetText('AllforOne')

    local desc = f:CreateFontString(nil, 'ARTWORK')
    desc:SetFontObject('GameFontHighlight')
    desc:SetJustifyV('TOP')
    desc:SetJustifyH('LEFT')
    desc:SetPoint('TOPLEFT', 18, -32)
    desc:SetPoint('BOTTOMRIGHT', -18, 30)
    f.desc = desc

    f.disableButton = CreateFrame('CheckButton', f:GetName()..'DisableButton', f, 'UICheckButtonTemplate')
    _G[f.disableButton:GetName() .. 'Text']:SetText(DISABLE)
    f.disableButton:SetPoint('BOTTOMLEFT')
    S:HandleCheckBox(f.disableButton)
    f.disableButton:SetScript('OnShow', function(btn) btn:SetChecked(addonTable.db.hideTutorial) end)
    f.disableButton:SetScript('OnClick', function(btn) addonTable.db.hideTutorial = btn:GetChecked() end)

    f.hideButton = CreateFrame('Button', f:GetName()..'HideButton', f, 'UIPanelButtonTemplate')
    f.hideButton:SetPoint('BOTTOMRIGHT', -5, 5)
    S:HandleButton(f.hideButton)
    _G[f.hideButton:GetName() .. 'Text']:SetText(HIDE)
    f.hideButton:SetScript('OnClick', function(btn) StaticPopupSpecial_Hide(btn:GetParent()) end)

    f.nextButton = CreateFrame('Button', f:GetName()..'NextButton', f, 'UIPanelButtonTemplate')
    f.nextButton:SetPoint('RIGHT', f.hideButton, 'LEFT', -4, 0)
    f.nextButton:SetSize(20, 20)
    S:HandleButton(f.nextButton)
    _G[f.nextButton:GetName() .. 'Text']:SetText('>')
    f.nextButton:SetScript('OnClick', function() addonTable:SetNextTutorial() end)

    f.prevButton = CreateFrame('Button', f:GetName()..'PrevButton', f, 'UIPanelButtonTemplate')
    f.prevButton:SetPoint('RIGHT', f.nextButton, 'LEFT', -4, 0)
    f.prevButton:SetSize(20, 20)
    S:HandleButton(f.prevButton)
    _G[f.prevButton:GetName() .. 'Text']:SetText('<')
    f.prevButton:SetScript('OnClick', function() addonTable:SetPrevTutorial() end)

    return f
end

function addonTable:Tutorials(forceShow)
    if not forceShow and (addonTable.db.hideTutorial or not addonTable.private.install_complete) then return end

    StaticPopupSpecial_Show(AllforOneTutorialWindow or addonTable:SpawnTutorialFrame())
    addonTable:SetNextTutorial()
end

-- ROGUE.lua
return function(addonTable)
    -- Ensure the GetRotationFunction table exists
    addonTable.GetRotationFunction = addonTable.GetRotationFunction or {}

    -- Helper function to cast a spell if usable and off cooldown
    local function castIfUsable(spellName, debuffCheck)
        local usable, noCooldown = IsUsableSpell(spellName), GetSpellCooldown(spellName) == 0
        if usable and noCooldown and (not debuffCheck or not UnitDebuff("target", spellName)) then
            CastSpellByName(spellName)
        end
    end

    -- Define rotation logic for Rogue specializations
    addonTable.GetRotationFunction["ROGUE"] = {
        ["ASSASSINATION"] = function()
            -- Assassination Rogue rotation logic
            castIfUsable("Garrote", true)
            castIfUsable("Rupture", true)
            castIfUsable("Mutilate")
            castIfUsable("Envenom")
        end,
        ["OUTLAW"] = function()
            -- Outlaw Rogue rotation logic
            castIfUsable("Sinister Strike")
            castIfUsable("Roll the Bones")
            castIfUsable("Dispatch")
            castIfUsable("Between the Eyes")
        end,
        ["SUBTLETY"] = function()
            -- Subtlety Rogue rotation logic
            castIfUsable("Shadowstrike")
            castIfUsable("Eviscerate")
            castIfUsable("Backstab")
            castIfUsable("Symbols of Death")
        end,
    }
end
